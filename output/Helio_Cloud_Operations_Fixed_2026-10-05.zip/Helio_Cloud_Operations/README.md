# Helio Operations — verified local release

This archive preserves the runtime source used for the completed 30 September–1 October 2026 verification: twelve FastAPI microservices, service-owned PostgreSQL databases, Kafka events, real Docker worker scaling, encrypted S3-compatible storage, local SMTP delivery and coordinated backup/restore.

It intentionally excludes the later, unverified Ollama, trained-maintenance, forecast-driven scaling, off-site backup and Helm/HA experiments. Read `docs/CLOUD_STATUS.md` before presenting the project.

## Start in VS Code

Requirements: Docker Desktop with the Linux engine running, Python 3.11 or later for the launcher, several GB of free disk space and enough memory for the containers.

1. Extract this ZIP and open the `Helio_Cloud_Operations` folder in VS Code.
2. Start Docker Desktop and wait for **Engine running**.
3. In the VS Code terminal run:

```powershell
python run_local.py --open
```

The first build downloads pinned images and dependencies. Open `http://127.0.0.1:8080` if the browser does not open. The terminal prints a one-time server setup token for creating the first administrator. It is not a login password. Show it again with:

```powershell
python distributed/scripts/setup.py --show-setup-token
```

After the first build, use `python run_local.py --no-build --open`. Stop this project while preserving data volumes with `python run_local.py --stop`. The local SMTP inbox is `http://127.0.0.1:8025`.

### Startup repair (5 October 2026)

The launcher now checks all database logins before starting the services. It recognizes its own unhealthy gateway and can recover it, and reports startup failures without a Python traceback. It refuses to manage a same-named Compose deployment from another folder.

If the launcher reports database access failures after replacing `.env`, run:

```powershell
python run_local.py --repair-database --no-build --open
```

This stops application services, saves the existing `.env` and a complete PostgreSQL dump under `.recovery/`, and changes the 13 PostgreSQL login passwords to match the current `.env` in one transaction. It then starts and checks the stack. It does not delete volumes, users, or stored files. The PostgreSQL container must permit its normal local administrator connection; recovery stops if it cannot create a backup.

If access credentials were exposed, add `--rotate-access-secrets` to the recovery command. This rotates database passwords, the shared internal secret, setup token and local S3 secret. Authentication/storage encryption keys remain unchanged because existing data may depend on them. Their rotation requires a separate migration. Use this option only with the bundled local S3 service.

Keep `.env` with its matching data volumes. Keep `.recovery/` private; it contains secrets and database records and is excluded from Git and Docker builds. Do not run `docker compose down -v` to fix a login problem. If you move the project, stop the original deployment from its original folder first; use a distinct Compose project name and ports for a separate installation.

Launcher regression checks (Python standard library only):

```powershell
python -m unittest discover -s distributed/tests -p test_startup.py
```

## What is real in this release

| Area | Implemented behaviour |
|---|---|
| Microservices | Twelve separate service containers, private service APIs and a gateway for browser requests. |
| Data ownership | Each service has its own PostgreSQL database/login; services exchange information through APIs and Kafka. |
| Identity | Initial administrator setup, PBKDF2 password hashes, expiring/revocable sessions, roles, CSRF protection, throttling and TOTP MFA. |
| Monitoring | Measured latency, response status, request rate, worker readiness and gateway process measurements. |
| Incidents | Threshold-based creation, ownership, acknowledgement, investigation notes and fresh-evidence resolution. |
| Capacity | Actual Docker worker creation/removal, readiness verification, bounded HTTP workload tests, measured-demand autoscaling and failed-worker replacement. |
| Messaging | Kafka topics, transactional outboxes, consumer deduplication, bounded retries, failed-event inspection and replay. |
| Logs | Persisted/searchable logs, basic secret/email redaction and deterministic findings linked to evidence IDs. |
| Storage | Encrypted S3-compatible object bytes, checksums, versions and application-level retention. |
| Notifications | Persistent inbox, local SMTP through Mailpit, retry and duplicate suppression. |
| Recovery | Encrypted service snapshots and file archives, checksum/temporary-table verification, actual restore and session revocation. |
| Forecasting | Simple chronological statistical forecasting with held-out MAE/baseline reporting. |
| Costs/SLOs | Explicit partial estimates and measured request success/latency ratios. |

## Architecture

```text
Browser → API gateway → twelve independently running services
                         ├─ service-owned PostgreSQL databases
                         ├─ transactional outbox → Kafka → deduplicating consumers
                         ├─ capacity controller → Docker workload containers
                         ├─ storage service → encrypted SeaweedFS S3 objects
                         └─ notification worker → Mailpit
```

The same application image is started with twelve different service modules and credentials. This is a local single-host deployment: one PostgreSQL server, one Kafka broker and one SeaweedFS installation. Only ports 8080 and 8025 are published on loopback.

## Demonstration sequence

1. Create administrator, operator and viewer accounts; show that roles block unauthorized actions.
2. Run a bounded workload with one worker, then scale to two workers and show the verified replica history.
3. Open Command Center, Services and Log Intelligence to show measured evidence and timestamps.
4. Enable measured-demand autoscaling and show bounds, cooldown and the `autoscaler` action history.
5. Acknowledge an incident, add investigation notes and resolve it only after fresh recovery evidence.
6. Send an email notification and open Mailpit. Describe this as local SMTP acceptance.
7. Upload, version, download and checksum a file; demonstrate retention protection.
8. Create and verify a backup. A full restore requires the backup ID and administrator password and signs users out.
9. Show Connections and Audit Trail, then explain the limitations in `docs/CLOUD_STATUS.md`.

## Verification evidence

- 13 focused regression checks passed.
- 18 real-stack integration and fault checks passed.
- 21 browser workflow checks passed.
- 8 clean-source archive/startup checks passed.

These results apply to the verified runtime preserved in this archive. They establish the tested workflows; they are not a production certification. See `docs/VERIFICATION.md` and the sanitized JSON reports under `docs/verification/`.

## Source layout

```text
web/                          Browser interface and offline API reference
distributed/helio/           Shared transport plus twelve service modules
distributed/infra/           PostgreSQL database/role initialization
distributed/scripts/         Secret generation and Docker launcher
distributed/tests/           Regression, integration and browser checks
services/workload/           Managed CPU-bound HTTP workload
run_local.py                  Supported launcher
```

The generated `distributed/.env` contains secrets and is excluded from the ZIP. Keep it private. Do not change encryption keys while retaining old encrypted objects or MFA secrets.
